import asyncio 

async def task1(name,delay):
    print(f"task of {name} is started ")
    await asyncio.sleep(delay) 
    print(f"task of {name} is completed, after delay {delay}") 

async def task2(name,delay):
    print(f"task of {name} is started") 
    await asyncio.sleep(1) 
    print(f"task of {name} is completed after delay {delay}") 


async def main():
    # gather task will execute concurrently
    await asyncio.gather(   # here await means, first complete these gathered task and you can create may be another gather list of task.
        task1("A",3), 
        task2("B",1)
    )

asyncio.run(main())