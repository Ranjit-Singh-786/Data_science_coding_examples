import asyncio

async def task1():
    await asyncio.sleep(3)  # wait for 3 seconds before execute next line
    print("Task 1 done")
async def task2():
    print("Task done2")

async def main():
    await task1()    
    await task2()  # here complete task1 then task2

# Entry point of script
if __name__ == "__main__":
    asyncio.run(main())
