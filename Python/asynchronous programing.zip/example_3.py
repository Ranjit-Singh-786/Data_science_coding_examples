import asyncio 

async def task1(name,delay):
    print(f"task of {name} is started ")
    await asyncio.sleep(delay) 
    print(f"task of {name} is completed, after delay {delay}") 

async def task2(name,delay):
    print(f"task of {name} is started") 
    await asyncio.sleep(1) 
    print(f"task of {name} is completed after delay {delay}") 

async def task3():
    print("this is separate task outside the gather")
    await asyncio.sleep(8)


async def main():
    # gather task will execute concurrently
    await asyncio.gather(
        task1("A",3),
        task2("B",1),
    )
    await task3()  # will execute after gather functions 
    print("this is from main function! ❤️")  # execute in last
asyncio.run(main())