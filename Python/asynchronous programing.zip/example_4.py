import asyncio

def sync_function():
    print("I am a normal function.")

async def async_function():
    print("Start async")
    await asyncio.sleep(1)
    print("End async")

async def main():
    sync_function()           # called normally
    await async_function()    # must be awaited

asyncio.run(main())
