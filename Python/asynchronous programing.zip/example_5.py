import asyncio

async def countdown(name, start):
    for i in range(start, 0, -1):
        print(f"{name}: {i}")
        await asyncio.sleep(1)
    print(f"{name} done!")

async def main():
    await asyncio.gather(
        countdown("Timer 1", 3),
        countdown("Timer 2", 5)
    )

asyncio.run(main())
